﻿<#
  SPS Group - MCP SAP Business One - ATUALIZADOR (tarefa do Windows "SPS MCP B1 - Atualizador").

  Roda como SISTEMA, a cada minuto. Quase sempre sai na hora: so trabalha quando o gerenciador
  (botao "Atualizar versao") deixou um pedido em C:\ProgramData\SPS-MCP-B1\atualizacoes\pedido.json.

  Passos:
    1. confere de novo o pacote com a chave publica do produto JA INSTALADO
       (carimbo da SPS na ficha + SHA-256 e tamanho do zip) - sem isso, nao instala nada;
    2. extrai o zip numa pasta temporaria e roda o instalar.ps1 sem janela (por cima, mantendo
       conexoes, usuarios, perfis e configuracoes);
    3. escreve o andamento em atualizacoes\estado-instalador.json (o gerenciador mostra na tela)
       e tudo em logs\atualizacao.log.
#>
$ErrorActionPreference = 'Stop'
$Dados = Join-Path $env:ProgramData 'SPS-MCP-B1'
$Pasta = Join-Path $Dados 'atualizacoes'
$Pedido = Join-Path $Pasta 'pedido.json'
if (-not (Test-Path $Pedido)) { exit 0 }   # nada pedido: sai sem fazer nada

$Programa = $PSScriptRoot
$Log = Join-Path $Dados 'logs\atualizacao.log'
$Utf8 = New-Object Text.UTF8Encoding($false)
function Log([string]$t) {
    New-Item -ItemType Directory -Force (Split-Path $Log) | Out-Null
    [IO.File]::AppendAllText($Log, "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') $t`r`n", $Utf8)
}
function Estado([string]$fase, [string]$mensagem) {
    $json = @{ fase = $fase; mensagem = $mensagem; quando = (Get-Date).ToString('o') } | ConvertTo-Json -Compress
    [IO.File]::WriteAllText((Join-Path $Pasta 'estado-instalador.json'), $json, $Utf8)
}

# uma atualizacao por vez (trava com validade de 40 min, caso algo tenha caido no meio)
$Trava = Join-Path $Pasta 'instalando.trava'
if ((Test-Path $Trava) -and ((Get-Date) - (Get-Item $Trava).LastWriteTime).TotalMinutes -lt 40) { exit 0 }
Set-Content $Trava (Get-Date -Format o) -Encoding ASCII

$EmAndamento = Join-Path $Pasta 'pedido-em-andamento.json'
$Temp = $null
try {
    Move-Item $Pedido $EmAndamento -Force   # o pedido nao roda duas vezes
    Log '----- pedido de atualizacao recebido -----'

    # 1. conferencia (carimbo da SPS + SHA-256), com o produto ja instalado
    $node = Join-Path $Programa 'runtime\SpsMcpB1.exe'
    $conferir = Join-Path $Programa 'app\dist\sps\conferir-pacote.js'
    if (-not (Test-Path $node) -or -not (Test-Path $conferir)) { throw 'instalacao atual incompleta (runtime ou conferir-pacote.js ausente)' }
    $saida = (& $node $conferir $EmAndamento | Out-String).Trim()
    if ($LASTEXITCODE -ne 0 -or $saida -notmatch '^OK (\S+) (.+)$') { throw "pacote recusado: $saida" }
    $versao = $Matches[1]; $zip = $Matches[2].Trim()
    Log "pacote conferido: versao $versao ($zip)"
    Estado 'instalando' "Instalando a versão $versao… o painel fica fora do ar por cerca de 1 minuto."

    # 2. extrai e instala por cima (sem janela)
    $Temp = Join-Path $env:TEMP "sps-mcp-b1-atualizacao-$versao"
    if (Test-Path $Temp) { Remove-Item $Temp -Recurse -Force }
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($zip, $Temp)
    $instalador = Get-ChildItem $Temp -Recurse -Filter 'instalar.ps1' | Select-Object -First 1
    if (-not $instalador) { throw 'instalar.ps1 nao encontrado no pacote' }
    Log "instalando a partir de $($instalador.DirectoryName)"
    # instala na MESMA pasta onde o programa esta hoje (pode nao ser a padrao)
    $saidaInst = (& powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -File $instalador.FullName -Destino $Programa -SemJanela 2>&1 | Out-String)
    $codigo = $LASTEXITCODE
    Log $saidaInst.Trim()
    if ($codigo -ne 0) { throw "o instalador terminou com erro (codigo $codigo). Veja $Log" }
    Estado 'concluido' "Versão $versao instalada."
    Log "versao $versao instalada"
} catch {
    $msg = $_.Exception.Message
    Log "ERRO: $msg"
    try { Estado 'erro' "Atualização não concluída: $msg" } catch { }
} finally {
    Remove-Item $EmAndamento -Force -ErrorAction SilentlyContinue
    if ($Temp -and (Test-Path $Temp)) { Remove-Item $Temp -Recurse -Force -ErrorAction SilentlyContinue }
    # o pacote baixado (~47 MB) nao serve mais: instalado ou recusado, uma nova tentativa baixa de novo
    Get-ChildItem $Pasta -Filter 'SPS-MCP-B1-*.zip*' -ErrorAction SilentlyContinue | Remove-Item -Force -ErrorAction SilentlyContinue
    Remove-Item $Trava -Force -ErrorAction SilentlyContinue
}
