﻿<#
  SPS Group - MCP SAP Business One - instalador (com janela e barra de progresso)

  Uso normal: clique duas vezes em instalar.cmd (ele pede permissão de administrador).
  Avançado:   powershell -ExecutionPolicy Bypass -File instalar.ps1 [-Destino "C:\..."] [-PortaMcp 3000] [-PortaPainel 3001] [-SemJanela]

  O que ele toca no Windows (e NADA além disso):
    - pasta do programa:  C:\Program Files\SPS\MCP-B1  (subpastas app, runtime, servico e arquivos da SPS)
    - pasta de dados:     C:\ProgramData\SPS-MCP-B1
    - serviço:            SpsMcpB1, rodando com a conta própria e limitada "NT SERVICE\SpsMcpB1"
    - atalhos:            "SPS MCP B1 - Painel" na área de trabalho pública e no Menu Iniciar (pasta SPS Group)
    - firewall:           regra "SPS MCP B1" só para a porta do MCP (quem entra é decidido no
                          painel > Configurações > Acesso pela rede; o padrão é "só este servidor")
    - superusuário:       na instalação nova pede e-mail/nome/senha do superusuário principal
  Não instala Node no sistema, não mexe no PATH, não altera outros serviços ou programas.
  Se algo não bater (porta ocupada e sem outra escolhida, pasta de outro programa, serviço
  com o mesmo nome que não é o nosso), para ANTES de mudar qualquer coisa.
  Numa atualização, nada do cliente (conexão SAP, usuários, perfis, .env, logs) é apagado.
#>
param(
    [string]$Destino = (Join-Path $env:ProgramFiles 'SPS\MCP-B1'),
    [int]$PortaMcp = 3000,
    [int]$PortaPainel = 3001,
    [switch]$AbrirFirewall,   # mantido por compatibilidade: a regra agora é sempre criada
    [switch]$SemJanela
)

$ErrorActionPreference = 'Stop'
$script:SemJanela = [bool]$SemJanela
. (Join-Path $PSScriptRoot 'ui-sps.ps1')

$Servico    = 'SpsMcpB1'
$Conta      = "NT SERVICE\$Servico"
$Exibicao   = 'SPS Group - MCP SAP Business One'
$Descricao  = 'SPS Group | MCP para SAP Business One: conecta Claude e ChatGPT ao SAP B1 com controle de acesso. Painel em http://127.0.0.1 (porta do painel no .env).'
$NomeAtalho = 'SPS MCP B1 - Painel'
$RegraFw    = 'SPS MCP B1'
$Dados      = Join-Path $env:ProgramData 'SPS-MCP-B1'
$Origem     = $PSScriptRoot
$Destino    = $Destino.TrimEnd('\')
$exeServico = Join-Path $Destino 'servico\SpsMcpB1Servico.exe'
$arqEnv     = Join-Path $Dados '.env'
$ArquivosSps = @('atualizar.ps1', 'desinstalar.ps1','desinstalar.cmd', 'redefinir-senha.ps1', 'redefinir-senha.cmd', 'ver-log.cmd', 'ui-sps.ps1', 'testar-mcp.ps1', 'LEIA-ME.txt', 'sps.ico', 'logo_sps.png')

# erro "esperado": para sem ter mudado nada (ou devolvendo como estava)
function Parar([string]$t) { throw "Não instalado: $t" }
function Executar([string]$exe, [string[]]$a) {
    & $exe @a | Out-Null
    if ($LASTEXITCODE -ne 0) { throw "$exe $($a -join ' ') falhou (código $LASTEXITCODE)" }
}
function VersaoDe([string]$pastaApp) {
    try { return (Get-Content (Join-Path $pastaApp 'package.json') -Raw | ConvertFrom-Json).version } catch { return '?' }
}

# Roda um script do app com o Node do pacote. A senha vai pela entrada padrão (stdin),
# nunca pela linha de comando (que aparece na lista de processos).
function RodarNode([string]$pastaBase, [string]$script, [string]$argumentos, [string]$entrada = '') {
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = Join-Path $pastaBase 'runtime\SpsMcpB1.exe'
    $psi.Arguments = "`"$(Join-Path $pastaBase "app\dist\sps\$script")`" $argumentos"
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.EnvironmentVariables['SPS_DATA_DIR'] = $Dados
    $p = [Diagnostics.Process]::Start($psi)
    if ($entrada) { $p.StandardInput.Write($entrada) }
    $p.StandardInput.Close()
    $saida = $p.StandardOutput.ReadToEnd(); $null = $p.StandardError.ReadToEnd(); $p.WaitForExit()
    return @{ Codigo = $p.ExitCode; Saida = $saida.Trim() }
}

# ---------- portas ----------
function PortaLivre([int]$p) { -not (Get-NetTCPConnection -State Listen -LocalPort $p -ErrorAction SilentlyContinue) }
function QuemUsa([int]$p) {
    $u = Get-NetTCPConnection -State Listen -LocalPort $p -ErrorAction SilentlyContinue | Select-Object -First 1
    if (-not $u) { return '?' }
    $pr = Get-Process -Id $u.OwningProcess -ErrorAction SilentlyContinue
    return "'$($pr.ProcessName)' (pid $($u.OwningProcess))"
}
# Devolve uma porta livre: a desejada, ou outra que o técnico digitar. 0 = cancelou.
function EscolherPorta([string]$nome, [int]$desejada, [int]$outra) {
    $p = $desejada
    while ($true) {
        if ($p -ne $outra -and (PortaLivre $p)) { return $p }
        if ($p -eq $outra) { $motivo = 'é igual à outra porta' } else { $motivo = 'está em uso por ' + (QuemUsa $p) }
        $sug = $p + 1
        while ($sug -lt 65535 -and ($sug -eq $outra -or -not (PortaLivre $sug))) { $sug++ }
        Aviso "porta $p do $nome $motivo"
        $r = Perguntar-Texto 'Porta ocupada' ("A porta $p do $nome $motivo.`n`nDigite outra porta (já sugeri a próxima livre)`nou clique em Cancelar para não instalar.") "$sug"
        if (-not $r) { return 0 }
        if ($r -match '^\d+$' -and [int]$r -ge 1024 -and [int]$r -le 65535) { $p = [int]$r }
        else { Aviso "porta inválida: '$r' (use um número de 1024 a 65535)" }
    }
}
# grava (ou troca) CHAVE=valor no .env, preservando o resto do arquivo
function DefinirNoEnv([string]$chave, [string]$valor) {
    $linhas = @(Get-Content $arqEnv)
    $achou = $false
    for ($i = 0; $i -lt $linhas.Count; $i++) {
        if ($linhas[$i] -match "^\s*$chave\s*=") { $linhas[$i] = "$chave=$valor"; $achou = $true }
    }
    if (-not $achou) { $linhas += "$chave=$valor" }
    Set-Content -Path $arqEnv -Value $linhas -Encoding ASCII
}

# ---------- cópia com barra de progresso ----------
function ContarLinhas([string]$arq) {
    if (-not (Test-Path $arq)) { return 0 }
    try {
        $fs = [IO.File]::Open($arq, 'Open', 'Read', 'ReadWrite')
        $sr = New-Object IO.StreamReader($fs); $n = 0
        while ($null -ne $sr.ReadLine()) { $n++ }
        $sr.Close(); return $n
    } catch { return 0 }
}
# Espelha $de em $para (robocopy /MIR) movendo a barra de $pctIni até $pctFim.
function CopiarComProgresso([string]$de, [string]$para, [int]$pctIni, [int]$pctFim, [string]$rotulo) {
    $opcoes = "`"$de`" `"$para`" /MIR /R:3 /W:2 /NJH /NJS /NDL /NC /NS /NP"
    # 1) simulação (/L): quantos arquivos vão ser copiados ou removidos
    $lista = Join-Path $env:TEMP "sps-mcp-b1-lista-$PID.txt"
    $p = Start-Process robocopy -ArgumentList "$opcoes /L /LOG:`"$lista`"" -WindowStyle Hidden -PassThru
    $null = $p.Handle; $p.WaitForExit()
    $total = [Math]::Max(1, (ContarLinhas $lista))
    Remove-Item $lista -Force -ErrorAction SilentlyContinue
    # 2) cópia de verdade, acompanhando o log
    $log = Join-Path $env:TEMP "sps-mcp-b1-copia-$PID.txt"
    $p = Start-Process robocopy -ArgumentList "$opcoes /LOG:`"$log`"" -WindowStyle Hidden -PassThru
    $null = $p.Handle
    while (-not $p.HasExited) {
        $feitos = [Math]::Min($total, (ContarLinhas $log))
        Progresso ($pctIni + [int](($pctFim - $pctIni) * $feitos / $total))
        Detalhe ("{0}: {1:N0} de {2:N0} arquivos" -f $rotulo, $feitos, $total)
        Start-Sleep -Milliseconds 150
    }
    Remove-Item $log -Force -ErrorAction SilentlyContinue
    if ($p.ExitCode -ge 8) { throw "Falha ao copiar '$rotulo' (robocopy código $($p.ExitCode))" }
    Progresso $pctFim
    return $total
}

# ======================================================================
$versaoNova = VersaoDe (Join-Path $Origem 'app')
Abrir-Janela "SPS MCP B1 - Instalação $versaoNova" "Instalando o SPS MCP B1 · versão $versaoNova" $Origem
$svcWmi = $null
$servicoParado = $false
$urlPainel = ''
$ok = $false
try {
    # ================= 0. conferências (nada foi alterado ainda) =================
    Etapa 2 'Conferindo permissões e o pacote...'
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { Parar 'execute como administrador (use o instalar.cmd).' }
    foreach ($p in 'app', 'runtime', 'servico') {
        if (-not (Test-Path (Join-Path $Origem $p))) { Parar "pacote incompleto (falta a pasta '$p'). Extraia o zip inteiro antes." }
    }
    if ((Resolve-Path $Origem).Path.TrimEnd('\') -eq $Destino) { Parar 'rode o instalar.cmd da pasta extraída do zip, não da pasta já instalada.' }
    Feito "pacote da versão $versaoNova conferido"

    # serviço com o mesmo nome: tem que ser o nosso, no mesmo local
    $svcWmi = Get-CimInstance Win32_Service -Filter "Name='$Servico'" -ErrorAction SilentlyContinue
    if ($svcWmi -and $svcWmi.PathName.Trim('"') -ne $exeServico) {
        Parar "já existe um serviço '$Servico' apontando para '$($svcWmi.PathName)'. Desinstale-o antes."
    }
    # pasta de destino: vazia, inexistente, ou uma instalação nossa
    if ((Test-Path $Destino) -and (Get-ChildItem $Destino -Force) -and -not (Test-Path $exeServico)) {
        Parar "a pasta '$Destino' já tem arquivos que não são do SPS MCP B1. Escolha outra com -Destino."
    }
    $versaoAtual = if (Test-Path (Join-Path $Destino 'app\package.json')) { VersaoDe (Join-Path $Destino 'app') } else { '' }
    if ($svcWmi) { Feito "atualização da versão $versaoAtual para $versaoNova" } else { Feito 'instalação nova' }
    Feito "programa: $Destino"
    Feito "dados do cliente: $Dados"

    # superusuário principal: se ainda não existe (instalação nova ou dados apagados), pergunta agora
    $novoSuper = $null
    $v = RodarNode $Origem 'criar-superusuario.js' '--verificar'
    if ($v.Saida -eq 'TEM') {
        Feito 'superusuário principal já existe (mantido)'
    } else {
        Etapa 4 'Superusuário principal...'
        $novoSuper = Pedir-Superusuario $Origem
        if (-not $novoSuper) { Parar 'é preciso criar o superusuário principal para usar o painel. Nada foi alterado.' }
        Feito "superusuário principal: $($novoSuper.Email) (será criado na instalação)"
    }

    # portas. Ordem: linha de comando > .env instalado > configuracao.txt > padrão 3000/3001
    $origemPortas = 'padrão'
    $arqConfig = Join-Path $Origem 'configuracao.txt'
    if (Test-Path $arqConfig) {
        foreach ($linha in Get-Content $arqConfig) {
            if ($linha -match '^\s*PORTA_MCP\s*=\s*(\d+)' -and -not $PSBoundParameters.ContainsKey('PortaMcp')) { $PortaMcp = [int]$Matches[1]; $origemPortas = 'configuracao.txt' }
            if ($linha -match '^\s*PORTA_PAINEL\s*=\s*(\d+)' -and -not $PSBoundParameters.ContainsKey('PortaPainel')) { $PortaPainel = [int]$Matches[1]; $origemPortas = 'configuracao.txt' }
        }
    }
    $portasDoEnv = @{}
    if (Test-Path $arqEnv) {
        foreach ($linha in Get-Content $arqEnv) {
            if ($linha -match '^\s*PORT\s*=\s*(\d+)') { $portasDoEnv.PORT = [int]$Matches[1] }
            if ($linha -match '^\s*SPS_ADMIN_PORT\s*=\s*(\d+)') { $portasDoEnv.SPS_ADMIN_PORT = [int]$Matches[1] }
        }
        if ($portasDoEnv.PORT -and -not $PSBoundParameters.ContainsKey('PortaMcp')) { $PortaMcp = $portasDoEnv.PORT; $origemPortas = '.env instalado' }
        if ($portasDoEnv.SPS_ADMIN_PORT -and -not $PSBoundParameters.ContainsKey('PortaPainel')) { $PortaPainel = $portasDoEnv.SPS_ADMIN_PORT; $origemPortas = '.env instalado' }
    }
    if ($PSBoundParameters.ContainsKey('PortaMcp') -or $PSBoundParameters.ContainsKey('PortaPainel')) { $origemPortas = 'linha de comando' }

    # ================= 1. para o serviço atual (só na atualização) =================
    if ($svcWmi) {
        Etapa 6 'Parando o serviço atual...'
        $svc = Get-Service $Servico
        if ($svc.Status -ne 'Stopped') {
            Stop-Service $Servico -Force
            $svc.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
            $servicoParado = $true
        }
        Feito 'serviço parado'
    }

    # portas livres? (com o nosso serviço já parado, qualquer uso é de outro programa)
    Etapa 10 'Conferindo as portas...'
    $PortaMcp = EscolherPorta 'MCP' $PortaMcp $PortaPainel
    if ($PortaMcp -ne 0) { $PortaPainel = EscolherPorta 'painel' $PortaPainel $PortaMcp }
    if ($PortaMcp -eq 0 -or $PortaPainel -eq 0) { Parar 'cancelado na escolha da porta. Nada foi alterado.' }
    Feito "portas: MCP $PortaMcp | painel $PortaPainel (de: $origemPortas)"

    # ================= 2. copia o programa =================
    Etapa 14 'Copiando o programa e as dependências...'
    New-Item -ItemType Directory -Force $Destino | Out-Null
    $n = CopiarComProgresso (Join-Path $Origem 'app') (Join-Path $Destino 'app') 14 72 'aplicação e dependências'
    Feito ("aplicação e dependências copiadas ({0:N0} arquivos)" -f $n)
    Etapa 72 'Copiando o runtime (Node.js LTS)...'
    $null = CopiarComProgresso (Join-Path $Origem 'runtime') (Join-Path $Destino 'runtime') 72 80 'runtime'
    $null = CopiarComProgresso (Join-Path $Origem 'servico') (Join-Path $Destino 'servico') 80 82 'serviço'
    foreach ($f in $ArquivosSps) { if (Test-Path (Join-Path $Origem $f)) { Copy-Item (Join-Path $Origem $f) $Destino -Force } }
    Feito 'runtime e serviço copiados'
    Etapa 83 'Desbloqueando os arquivos...'
    Get-ChildItem $Destino -Recurse -File | Unblock-File   # zip baixado da internet vem "bloqueado"
    Feito 'arquivos desbloqueados'

    # ================= 3. serviço =================
    Etapa 86 'Registrando o serviço do Windows...'
    if (-not $svcWmi) {
        New-Service -Name $Servico -BinaryPathName "`"$exeServico`"" -DisplayName $Exibicao -Description $Descricao -StartupType Automatic | Out-Null
        $svcWmi = Get-CimInstance Win32_Service -Filter "Name='$Servico'"
    } else {
        Executar 'sc.exe' @('config', $Servico, 'DisplayName=', $Exibicao)
        Executar 'sc.exe' @('description', $Servico, $Descricao)
    }
    # Conta do serviço: a do NOC é aplicada À MÃO (services.msc > Fazer logon). O instalador
    # só usa a conta própria do produto na instalação nova; numa atualização, mantém a conta
    # que estiver lá (nunca desfaz a do NOC).
    $contaAtual = [string]$svcWmi.StartName
    $contaManual = $contaAtual -and $contaAtual -ne $Conta -and $contaAtual -ne 'LocalSystem'
    if ($contaManual) {
        Feito "conta do serviço mantida: $contaAtual (aplicada manualmente)"
    } else {
        Executar 'sc.exe' @('config', $Servico, 'obj=', $Conta)              # conta própria e limitada
        Feito "conta do serviço: $Conta (troque pela do NOC em services.msc, se preciso)"
    }
    # "SID do serviço": o Windows põe NT SERVICE\SpsMcpB1 no acesso do processo com QUALQUER conta.
    # Assim a pasta de dados (liberada para esse SID) funciona também com a conta do NOC, sem mexer em permissão.
    Executar 'sc.exe' @('sidtype', $Servico, 'unrestricted')
    Executar 'sc.exe' @('config', $Servico, 'start=', 'delayed-auto')        # espera a rede subir
    Executar 'sc.exe' @('failure', $Servico, 'reset=', '86400', 'actions=', 'restart/5000/restart/15000/restart/60000')
    Feito "serviço '$Exibicao' (início automático)"

    # ================= 4. pasta de dados e permissões =================
    Etapa 89 'Preparando a pasta de dados e as permissões...'
    New-Item -ItemType Directory -Force $Dados, (Join-Path $Dados 'logs'), (Join-Path $Dados 'certs') | Out-Null
    # Dados: só SYSTEM, Administradores e a conta do serviço (SIDs: funciona em qualquer idioma).
    # 1) protege SÓ a pasta (sem /T): tira a herança do ProgramData e concede os três, herdáveis;
    # 2) os arquivos e subpastas voltam a HERDAR da pasta (/reset). Antes o /inheritance:r com /T
    #    deixava arquivos criados pelo MCP (ex.: config.json regravado pelo painel) SEM nenhuma
    #    permissão - nem o serviço nem o administrador abriam, e o MCP não subia (Xodó, 07/11/2026).
    # Se algum arquivo já estiver sem permissão, a posse volta aos Administradores antes do /reset.
    Executar 'icacls' @($Dados, '/inheritance:r', '/grant:r', '*S-1-5-18:(OI)(CI)F', '*S-1-5-32-544:(OI)(CI)F', "${Conta}:(OI)(CI)M", '/Q')
    $eapAntes = $ErrorActionPreference; $ErrorActionPreference = 'Continue'   # (PS 5.1: saída de erro de programa externo não pode derrubar o script)
    try {
        & icacls (Join-Path $Dados '*') /reset /T /C /Q *> $null
        $resetOk = ($LASTEXITCODE -eq 0)
        if (-not $resetOk) {
            & icacls $Dados /setowner '*S-1-5-32-544' /T /C /Q *> $null
            & icacls (Join-Path $Dados '*') /reset /T /C /Q *> $null
            $resetOk = ($LASTEXITCODE -eq 0)
        }
    } finally { $ErrorActionPreference = $eapAntes }
    if (-not $resetOk) { Aviso "algumas permissões em $Dados não puderam ser corrigidas (veja com: icacls $Dados\* )" }
    Executar 'icacls' @($Destino, '/grant', "${Conta}:(OI)(CI)RX", '/Q')
    Feito 'pasta de dados protegida (SYSTEM, Administradores e o serviço)'

    if ($novoSuper) {
        $json = @{ email = $novoSuper.Email; nome = $novoSuper.Nome; senha = $novoSuper.Senha; ips = @($novoSuper.Ips) } | ConvertTo-Json -Compress
        $c = RodarNode $Destino 'criar-superusuario.js' '--criar' $json
        $novoSuper.Senha = $null; $json = $null
        if ($c.Saida -ne 'OK') { throw "Não foi possível criar o superusuário principal: $($c.Saida)" }
        Feito "superusuário principal criado: $($novoSuper.Email)"
    }

    # ================= 5. .env técnico =================
    if (Test-Path $arqEnv) {
        if ($portasDoEnv.PORT -ne $PortaMcp) { DefinirNoEnv 'PORT' $PortaMcp }
        if ($portasDoEnv.SPS_ADMIN_PORT -ne $PortaPainel) { DefinirNoEnv 'SPS_ADMIN_PORT' $PortaPainel }
        Feito '.env existente mantido'
    } else {
        $conteudo = @"
# SPS MCP B1 - configuracao TECNICA (so o tecnico mexe aqui).
# A conexao com o SAP, usuarios e perfis ficam no painel: http://127.0.0.1:$PortaPainel
# Depois de alterar este arquivo, reinicie o servico "$Exibicao".

PORT=$PortaMcp
SPS_ADMIN_PORT=$PortaPainel
NODE_ENV=production

# Em qual endereco o MCP escuta. 127.0.0.1 = so o proprio servidor (tunel/proxy local).
# (Use o painel > Configuracoes > Acesso pela rede: ele tem prioridade sobre esta linha.)
MCP_HOST=127.0.0.1

# HTTPS direto no MCP (desligado: use um proxy/tunel com HTTPS na frente quando publicar).
# Para ligar: coloque server.key e server.crt em $Dados\certs e troque para true.
HTTPS_ENABLED=false
HTTPS_KEY_PATH=$Dados\certs\server.key
HTTPS_CERT_PATH=$Dados\certs\server.crt

# Nomes pelos quais o MCP pode ser chamado (inclua o endereco publico quando publicar).
MCP_ALLOWED_HOSTS=127.0.0.1,localhost
# Endereco externo do MCP, quando publicado (ex.: https://mcp.cliente.com.br/)
# MCP_BASE_URL=

APP_LOG_LEVEL=info
"@
        Set-Content -Path $arqEnv -Value $conteudo -Encoding ASCII
        Feito '.env técnico criado'
    }

    # ================= 6. atalhos =================
    Etapa 92 'Criando os atalhos...'
    $conteudoUrl = "[InternetShortcut]`r`nURL=http://127.0.0.1:$PortaPainel/`r`nIconFile=$(Join-Path $Destino 'sps.ico')`r`nIconIndex=0`r`n"
    foreach ($a in @(
            (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) "$NomeAtalho.url"),
            (Join-Path ([Environment]::GetFolderPath('CommonPrograms')) "SPS Group\$NomeAtalho.url"))) {
        New-Item -ItemType Directory -Force (Split-Path $a) | Out-Null
        [IO.File]::WriteAllText($a, $conteudoUrl, [Text.Encoding]::ASCII)
    }
    Feito "atalho '$NomeAtalho' na área de trabalho e no Menu Iniciar"
    # "Esqueci a senha": só no Menu Iniciar (pede administrador ao abrir)
    $ws = New-Object -ComObject WScript.Shell
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'SPS Group\SPS MCP B1 - Redefinir senha.lnk'))
    $lnk.TargetPath = Join-Path $Destino 'redefinir-senha.cmd'; $lnk.WorkingDirectory = $Destino
    $lnk.IconLocation = "$(Join-Path $Destino 'sps.ico'),0"; $lnk.Description = 'SPS MCP B1 - redefinir a senha de um usuário do painel'
    $lnk.Save()
    Feito "atalho 'SPS MCP B1 - Redefinir senha' no Menu Iniciar (esqueci a senha)"
    # "Ver log": abre o servico.log no Bloco de Notas (pede administrador; funciona mesmo com o MCP parado)
    $lnk = $ws.CreateShortcut((Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'SPS Group\SPS MCP B1 - Ver log.lnk'))
    $lnk.TargetPath = Join-Path $Destino 'ver-log.cmd'; $lnk.WorkingDirectory = $Destino
    $lnk.IconLocation = "$(Join-Path $Destino 'sps.ico'),0"; $lnk.Description = 'SPS MCP B1 - abrir o log do serviço'
    $lnk.Save()
    Feito "atalho 'SPS MCP B1 - Ver log' no Menu Iniciar"

    # ================= 6b. tarefa do atualizador =================
    # O botão "Atualizar versão" do painel só BAIXA e confere o pacote: o serviço roda com conta
    # limitada (exposta à internet) e não pode trocar o programa. Quem instala é esta tarefa, como
    # SISTEMA, a cada minuto - mas o "cmd" só abre o atualizar.ps1 se houver pedido (custo quase zero).
    # O atualizar.ps1 confere de novo o carimbo da SPS e a impressão digital antes de instalar.
    Etapa 93 'Registrando o atualizador...'
    $tarefaNome = 'SPS MCP B1 - Atualizador'; $tarefaPasta = '\SPS Group\'
    $pedidoAtu = Join-Path $Dados 'atualizacoes\pedido.json'
    $argsTarefa = "/c if exist `"$pedidoAtu`" powershell.exe -NoProfile -NonInteractive -ExecutionPolicy Bypass -WindowStyle Hidden -File `"$(Join-Path $Destino 'atualizar.ps1')`""
    $tarefaAtual = Get-ScheduledTask -TaskName $tarefaNome -TaskPath $tarefaPasta -ErrorAction SilentlyContinue
    if ($tarefaAtual -and $tarefaAtual.Actions.Count -eq 1 -and $tarefaAtual.Actions[0].Arguments -eq $argsTarefa) {
        Feito "atualizador já registrado (tarefa '$tarefaNome')"   # (inclusive quando é ele que está rodando esta instalação)
    } else {
        $acao = New-ScheduledTaskAction -Execute "$env:SystemRoot\System32\cmd.exe" -Argument $argsTarefa
        $gatilhos = @(
            (New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(1) -RepetitionInterval (New-TimeSpan -Minutes 1)),
            (New-ScheduledTaskTrigger -AtStartup))
        $quem = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
        $regras = New-ScheduledTaskSettingsSet -MultipleInstances IgnoreNew -ExecutionTimeLimit (New-TimeSpan -Minutes 45) `
            -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
        Register-ScheduledTask -TaskName $tarefaNome -TaskPath $tarefaPasta -Action $acao -Trigger $gatilhos -Principal $quem -Settings $regras `
            -Description 'SPS Group - instala as atualizações do SPS MCP B1 pedidas no painel (somente pacotes com o carimbo da SPS).' -Force | Out-Null
        Feito "atualizador registrado (tarefa '$tarefaNome', Agendador de Tarefas > SPS Group)"
    }
    New-Item -ItemType Directory -Force (Join-Path $Dados 'atualizacoes') | Out-Null

    # Claude Desktop: usa o conector com login (Configuracoes > Conectores), igual ao claude.ai.
    # A antiga ponte sem login (claude_desktop_config.exemplo.json) nao funciona mais: tira o arquivo velho.
    Remove-Item (Join-Path $Destino 'claude_desktop_config.exemplo.json') -Force -ErrorAction SilentlyContinue

    # ================= 7. firewall =================
    # A regra deixa a porta do MCP passar pelo firewall do Windows. Sozinha ela não expõe nada:
    # o MCP só escuta na rede quando o painel tem "Este servidor e a rede" ligado, e mesmo
    # assim só aceita os IPs liberados lá. O painel (porta $PortaPainel) nunca sai do servidor.
    Etapa 94 "Firewall da porta $PortaMcp..."
    Get-NetFirewallRule -DisplayName $RegraFw -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    New-NetFirewallRule -DisplayName $RegraFw -Group $RegraFw -Direction Inbound -Protocol TCP -LocalPort $PortaMcp -Action Allow | Out-Null
    Feito "firewall: porta $PortaMcp (quem entra é decidido no painel > Configurações > Acesso pela rede)"

    # ================= 8. inicia e confere =================
    Etapa 96 'Iniciando o serviço...'
    Start-Service $Servico
    $servicoParado = $false
    $urlPainel = "http://127.0.0.1:$PortaPainel/"
    for ($i = 30; $i -gt 0 -and -not $ok; $i--) {
        Detalhe "aguardando o painel responder ($i s)"
        for ($j = 0; $j -lt 10; $j++) { Atualizar-Tela; Start-Sleep -Milliseconds 100 }
        try { $ok = (Invoke-WebRequest -Uri ($urlPainel + 'api/estado') -UseBasicParsing -TimeoutSec 3).StatusCode -eq 200 } catch { }
    }
    if (-not $ok) { throw "O serviço foi instalado, mas o painel não respondeu em 30 s. Veja o log: $Dados\logs\servico.log" }
    Feito "serviço no ar; painel em $urlPainel"
} catch {
    Falhou $_.Exception.Message
    # atualização interrompida depois de parar o serviço: devolve como estava
    if ($servicoParado) { try { Start-Service $Servico; Aviso 'serviço anterior iniciado de novo' } catch { } }
}

if ($ok) {
    $abrir = Concluir $true "Instalação concluída - versão $versaoNova" 'Abrir o painel'
    if ($abrir) { Start-Process $urlPainel }
} else {
    $null = Concluir $false 'Instalação não concluída'
    exit 1
}
