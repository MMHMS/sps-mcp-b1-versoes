﻿<#
  SPS Group - MCP SAP Business One - desinstalador (com janela e barra de progresso)

  Uso normal: clique duas vezes em desinstalar.cmd (pede permissão de administrador).
  Sem perguntas: powershell -ExecutionPolicy Bypass -File desinstalar.ps1 -ManterDados   (ou -ApagarDados) [-SemJanela]

  Remove SOMENTE o que o instalador criou (serviço SpsMcpB1, regra de firewall "SPS MCP B1",
  atalhos "SPS MCP B1 - Painel", programa em C:\Program Files\SPS\MCP-B1).
  Não mexe em mais nada do Windows.
  Na tela inicial há a caixa "Remover também os dados de acesso configurados" (desmarcada):
  marcada, apaga também C:\ProgramData\SPS-MCP-B1 (conexão SAP, usuários, perfis, chave,
  .env e logs), com uma confirmação a mais. Desmarcada, uma nova instalação volta configurada.
#>
param(
    [switch]$ApagarDados,
    [switch]$ManterDados,
    [string]$Pasta = '',   # pasta do programa, caso o serviço já tenha sido removido (o .cmd informa)
    [switch]$SemJanela
)

$ErrorActionPreference = 'Stop'
$script:SemJanela = [bool]$SemJanela
. (Join-Path $PSScriptRoot 'ui-sps.ps1')

$Servico = 'SpsMcpB1'
$RegraFw = 'SPS MCP B1'
$Dados   = Join-Path $env:ProgramData 'SPS-MCP-B1'
$ArquivosSps = @('atualizar.ps1', 'desinstalar.ps1','desinstalar.cmd', 'redefinir-senha.ps1', 'redefinir-senha.cmd', 'ver-log.cmd', 'ui-sps.ps1', 'testar-mcp.ps1', 'LEIA-ME.txt', 'sps.ico', 'logo_sps.png', 'claude_desktop_config.exemplo.json')

Abrir-Janela 'SPS MCP B1 - Desinstalação' 'Desinstalando o SPS MCP B1' $PSScriptRoot

# Tela inicial: o que vai sair e a caixa "remover também os dados de acesso" (desmarcada)
if (-not $script:SemJanela -and -not $ApagarDados -and -not $ManterDados) {
    $r = Pedir-Inicio ("Vai remover deste servidor:`r`n" +
        "  - o serviço 'SPS Group - MCP SAP Business One'`r`n" +
        "  - o programa em C:\Program Files\SPS\MCP-B1 (inclui o runtime do Node)`r`n" +
        "  - os atalhos, a regra de firewall e a tarefa do atualizador (se houver)`r`n`r`n" +
        "Os dados de acesso configurados ficam guardados em $Dados,`r`n" +
        "a menos que você marque a caixa abaixo.") 'Desinstalar' `
        'Remover também os dados de acesso configurados (conexão SAP, senha, usuários, perfis, chave e logs). Não pode ser desfeito.'
    if (-not $r.Iniciar) {
        Etapa 0 'Desinstalação cancelada. Nada foi alterado.'
        $null = Concluir $false ''
        exit 0
    }
    if ($r.Marcado) {
        $certeza = Perguntar-SimNao 'Apagar os dados de acesso?' ("Você marcou para apagar também os dados de acesso:`n$Dados`n`n" +
            "Conexão SAP, senha criptografada, chave, usuários, perfis e logs serão apagados e NÃO podem ser recuperados.`n`nConfirma?")
        if ($certeza) { $ApagarDados = [switch]$true } else { $ManterDados = [switch]$true }
    } else {
        $ManterDados = [switch]$true
    }
}

$ok = $false
try {
    Etapa 3 'Conferindo permissões e a instalação...'
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Execute como administrador (use o desinstalar.cmd).' }
    if ($ApagarDados -and $ManterDados) { throw 'Use -ApagarDados OU -ManterDados, não os dois.' }

    # Descobre onde o programa está instalado (pelo serviço; senão, pela pasta informada)
    $svcWmi = Get-CimInstance Win32_Service -Filter "Name='$Servico'" -ErrorAction SilentlyContinue
    # Trava: só mexe no serviço se ele for mesmo o nosso (aponta para ...\servico\SpsMcpB1Servico.exe)
    if ($svcWmi -and -not ($svcWmi.PathName.Trim('"') -like '*\servico\SpsMcpB1Servico.exe')) {
        throw "O serviço '$Servico' existe mas aponta para '$($svcWmi.PathName)', que não é do SPS MCP B1. Nada foi alterado."
    }
    if ($svcWmi) { $Destino = Split-Path (Split-Path $svcWmi.PathName.Trim('"')) }
    elseif ($Pasta) { $Destino = $Pasta.TrimEnd('\', '.') }
    else { $Destino = $PSScriptRoot }
    $versao = '?'
    try { $versao = (Get-Content (Join-Path $Destino 'app\package.json') -Raw | ConvertFrom-Json).version } catch { }
    Feito "instalação encontrada: $Destino (versão $versao)"

    # ---------- 1. serviço ----------
    if ($svcWmi) {
        Etapa 10 'Parando o serviço...'
        $svc = Get-Service $Servico
        if ($svc.Status -ne 'Stopped') {
            Stop-Service $Servico -Force
            $svc.WaitForStatus('Stopped', [TimeSpan]::FromSeconds(30))
        }
        Feito 'serviço parado'
        Etapa 20 'Removendo o serviço...'
        & sc.exe delete $Servico | Out-Null
        # espera o Windows soltar os arquivos do serviço e do MCP
        for ($i = 0; $i -lt 20 -and (Get-Process -Name 'SpsMcpB1Servico', 'SpsMcpB1' -ErrorAction SilentlyContinue); $i++) { Start-Sleep -Milliseconds 500; Atualizar-Tela }
        Feito 'serviço removido'
    } else {
        Feito 'serviço não encontrado (já removido)'
    }

    # ---------- 2. firewall e atalhos ----------
    Etapa 26 'Removendo atalhos e regra de firewall...'
    Get-NetFirewallRule -DisplayName $RegraFw -ErrorAction SilentlyContinue | Remove-NetFirewallRule
    $nomeAtalho = 'SPS MCP B1 - Painel.url'
    $pastaMenu = Join-Path ([Environment]::GetFolderPath('CommonPrograms')) 'SPS Group'
    Remove-Item (Join-Path ([Environment]::GetFolderPath('CommonDesktopDirectory')) $nomeAtalho) -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $pastaMenu $nomeAtalho) -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $pastaMenu 'SPS MCP B1 - Redefinir senha.lnk') -Force -ErrorAction SilentlyContinue
    Remove-Item (Join-Path $pastaMenu 'SPS MCP B1 - Ver log.lnk') -Force -ErrorAction SilentlyContinue
    # a pasta "SPS Group" do Menu Iniciar só sai se ficar vazia (pode ter atalhos de outros produtos SPS)
    if ((Test-Path $pastaMenu) -and -not (Get-ChildItem $pastaMenu -Force)) { Remove-Item $pastaMenu -Force }
    Feito 'atalhos e regra de firewall removidos'
    # tarefa do atualizador (botão "Atualizar versão" do painel)
    $tarefa = Get-ScheduledTask -TaskName 'SPS MCP B1 - Atualizador' -TaskPath '\SPS Group\' -ErrorAction SilentlyContinue
    if ($tarefa) {
        $tarefa | Unregister-ScheduledTask -Confirm:$false
        # a pasta "SPS Group" do Agendador só sai se ficar vazia
        try {
            $agenda = New-Object -ComObject Schedule.Service; $agenda.Connect()
            $pastaTarefas = $agenda.GetFolder('\SPS Group')
            if ($pastaTarefas.GetTasks(1).Count -eq 0 -and $pastaTarefas.GetFolders(0).Count -eq 0) { $agenda.GetFolder('\').DeleteFolder('SPS Group', 0) }
        } catch { }
        Feito "tarefa 'SPS MCP B1 - Atualizador' removida"
    }

    # ---------- 3. programa ----------
    Etapa 30 'Removendo o programa...'
    # Trava de segurança: só apaga se a pasta for mesmo uma instalação do SPS MCP B1
    if (-not (Test-Path (Join-Path $Destino 'servico\SpsMcpB1Servico.exe'))) {
        Aviso "$Destino não parece uma instalação do SPS MCP B1; nada foi apagado ali"
    } else {
        Set-Location $env:TEMP   # sair da pasta para conseguir apagá-la
        # apaga pasta por pasta (cada pacote de dependência) para a barra andar
        $itens = @()
        $nm = Join-Path $Destino 'app\node_modules'
        if (Test-Path $nm) {
            foreach ($d in Get-ChildItem $nm -Directory -Force) {
                if ($d.Name.StartsWith('@')) { $itens += @(Get-ChildItem $d.FullName -Directory -Force | ForEach-Object { $_.FullName }); $itens += $d.FullName }
                else { $itens += $d.FullName }
            }
        }
        $itens += @((Join-Path $Destino 'app'), (Join-Path $Destino 'runtime'), (Join-Path $Destino 'servico'))
        $k = 0
        foreach ($alvo in $itens) {
            $k++
            if (Test-Path $alvo) {
                for ($t = 0; $t -lt 10 -and (Test-Path $alvo); $t++) {
                    try { Remove-Item $alvo -Recurse -Force -ErrorAction Stop } catch { Start-Sleep -Seconds 1 }
                }
            }
            if ($k % 5 -eq 0 -or $k -eq $itens.Count) {
                Progresso (30 + [int](55 * $k / $itens.Count))
                Detalhe ("{0:N0} de {1:N0} pastas" -f $k, $itens.Count)
            }
        }
        foreach ($p in 'app', 'runtime', 'servico') {
            if (Test-Path (Join-Path $Destino $p)) { Aviso "não consegui apagar $(Join-Path $Destino $p) (arquivo em uso?). Apague manualmente." }
        }
        foreach ($f in $ArquivosSps) { Remove-Item (Join-Path $Destino $f) -Force -ErrorAction SilentlyContinue }
        if (-not (Get-ChildItem $Destino -Force -ErrorAction SilentlyContinue)) { Remove-Item $Destino -Force -ErrorAction SilentlyContinue }
        $pai = Split-Path $Destino
        if ((Split-Path $pai -Leaf) -eq 'SPS' -and -not (Get-ChildItem $pai -Force -ErrorAction SilentlyContinue)) { Remove-Item $pai -Force -ErrorAction SilentlyContinue }
        Feito "programa removido ($Destino)"
    }

    # ---------- 4. dados do cliente ----------
    Etapa 88 'Dados do cliente...'
    if (Test-Path $Dados) {
        $apagar = $false
        if ($ApagarDados) { $apagar = $true }
        elseif (-not $ManterDados) {
            $apagar = Perguntar-SimNao 'Apagar os dados do cliente?' ("Os dados do cliente continuam em:`n$Dados`n`n" +
                "(conexão SAP, usuários, perfis, chave de criptografia, .env e logs)`n`n" +
                "Apagar também os dados? Isso NÃO pode ser desfeito.`n`n" +
                "Sim = apagar tudo`nNão = manter (uma nova instalação reaproveita tudo)")
        }
        if ($apagar) {
            Etapa 92 'Apagando os dados do cliente...'
            Remove-Item $Dados -Recurse -Force
            Feito 'dados do cliente apagados'
        } else {
            # pacotes baixados e pedidos de atualização não servem mais para nada
            Remove-Item (Join-Path $Dados 'atualizacoes') -Recurse -Force -ErrorAction SilentlyContinue
            # A conta do serviço (NT SERVICE\SpsMcpB1) é VIRTUAL: some sozinha com o serviço. Só sobra a
            # permissão dela na pasta de dados (aparece como "SID desconhecido"): tira pelo SID, que é
            # calculado do nome do serviço (S-1-5-80-...), porque o nome já não resolve mais.
            try {
                $sha = [Security.Cryptography.SHA1]::Create().ComputeHash([Text.Encoding]::Unicode.GetBytes($Servico.ToUpperInvariant()))
                $sid = 'S-1-5-80-' + ((0..4 | ForEach-Object { [BitConverter]::ToUInt32($sha, $_ * 4) }) -join '-')
                & icacls $Dados /remove:g "*$sid" /Q *> $null
            } catch { }
            Feito "dados do cliente mantidos em $Dados"
        }
    } else {
        Feito 'sem dados do cliente para remover'
    }
    $ok = $true
} catch {
    Falhou $_.Exception.Message
}

if ($ok) { $null = Concluir $true 'Desinstalação concluída' } else { $null = Concluir $false 'Desinstalação não concluída' }

# Apaga a própria cópia temporária (%TEMP%\sps-mcp-b1-desinstalar) logo depois de sair
if ((Split-Path $PSScriptRoot -Leaf) -eq 'sps-mcp-b1-desinstalar') {
    Start-Process cmd.exe -ArgumentList "/c ping 127.0.0.1 -n 3 >nul & rmdir /s /q `"$PSScriptRoot`"" -WindowStyle Hidden
}
if (-not $ok) { exit 1 }
