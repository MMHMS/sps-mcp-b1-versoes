@echo off
rem SPS MCP B1 - esqueci a senha do painel. Pede permissao de administrador e abre a janela.
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%~dp0redefinir-senha.ps1" %*
