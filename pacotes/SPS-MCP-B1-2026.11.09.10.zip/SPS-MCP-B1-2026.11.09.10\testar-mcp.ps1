﻿<#
  SPS MCP B1 - teste do MCP de ponta a ponta (somente LEITURA no SAP).

  Roda NO SERVIDOR onde o MCP esta instalado e conversa com ele do mesmo jeito que o
  Claude/ChatGPT conversa:
    1. confere se o MCP esta no ar (/health)
    1b. faz LOGIN como um usuario do painel (e-mail e senha) - igual ao Claude
    2. abre uma sessao MCP (initialize)
    3. lista as ferramentas
    4. procura a entidade no SAP (b1_find_entities)
    5. le os campos dela (b1_get_entity_schema)
    6. consulta 3 registros, so leitura (b1_read) - padrao: Items (ItemCode, ItemName)
  Nada e gravado no SAP. O SAP e acessado com a base e o usuario SAP desse usuario do painel.
  No fim o login de teste e desconectado.

  Uso: powershell -ExecutionPolicy Bypass -File testar-mcp.ps1 [-Email voce@empresa.com] [-Porta 3000] [-Entidade BusinessPartners]
  (sem -Porta, le a porta do C:\ProgramData\SPS-MCP-B1\.env)
#>
param(
    [int]$Porta = 0,
    [string]$Email = '',
    # Items (codigo e descricao) nao tem dado pessoal: o MCP le sem pedir confirmacao.
    # Entidades/campos com dado pessoal (ex.: BusinessPartners com CardName) exigem confirmacao
    # de uma pessoa no chat - protecao do MCP que este script nao tem como responder.
    [string]$Entidade = 'Items',
    [string]$Campos = 'ItemCode,ItemName'
)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'

if ($Porta -eq 0) {
    $Porta = 3000
    $arqEnv = Join-Path $env:ProgramData 'SPS-MCP-B1\.env'
    try { foreach ($l in Get-Content $arqEnv) { if ($l -match '^\s*PORT\s*=\s*(\d+)') { $Porta = [int]$Matches[1] } } } catch { }
}
$base = "http://127.0.0.1:$Porta"
$script:sessao = $null
$script:chave = $null
$script:cliente = $null
$script:id = 0

function Ok([string]$t) { Write-Host "  OK   $t" -ForegroundColor Green }
function Erro([string]$t) { Write-Host "  ERRO $t" -ForegroundColor Red }
function Passo([string]$t) { Write-Host ''; Write-Host ">> $t" -ForegroundColor Cyan }

# Corpo de erro HTTP (Invoke-WebRequest do PowerShell 5.1 joga excecao em 4xx/5xx)
function CorpoDoErro($e) {
    try {
        $r = $e.Exception.Response
        if (-not $r) { return $e.Exception.Message }
        $sr = New-Object IO.StreamReader($r.GetResponseStream())
        return "HTTP $([int]$r.StatusCode): " + $sr.ReadToEnd()
    } catch { return $e.Exception.Message }
}

# Chamada JSON-RPC ao MCP. A resposta pode vir em JSON ou em SSE ("data: {...}").
function Mcp([string]$metodo, $params, [switch]$Notificacao) {
    $msg = @{ jsonrpc = '2.0'; method = $metodo }
    if ($null -ne $params) { $msg.params = $params }
    if (-not $Notificacao) { $script:id++; $msg.id = $script:id }
    $h = @{ Accept = 'application/json, text/event-stream' }
    if ($script:sessao) { $h['Mcp-Session-Id'] = $script:sessao }
    if ($script:chave) { $h['Authorization'] = "Bearer $($script:chave)" }
    $corpo = [Text.Encoding]::UTF8.GetBytes(($msg | ConvertTo-Json -Depth 10 -Compress))
    $r = Invoke-WebRequest -Uri "$base/mcp" -Method Post -Headers $h -ContentType 'application/json' -Body $corpo -UseBasicParsing -TimeoutSec 180
    if ($r.Headers['Mcp-Session-Id']) { $script:sessao = $r.Headers['Mcp-Session-Id'] }
    if ($Notificacao) { return $null }
    # le os bytes como UTF-8 (o PowerShell 5.1 sozinho trocaria acentos: "GENERICO" viraria "GENÃRICO")
    $texto = [Text.Encoding]::UTF8.GetString($r.RawContentStream.ToArray())
    $json = $texto
    if ($texto -match '(?m)^data:') {
        $json = (($texto -split "`n") | Where-Object { $_ -match '^data:' } | Select-Object -Last 1) -replace '^data:\s*', ''
    }
    $resp = $json | ConvertFrom-Json
    if ($resp.error) { throw "MCP respondeu erro $($resp.error.code): $($resp.error.message)" }
    return $resp.result
}

function TextoDaFerramenta($resultado, [int]$max = 600) {
    $t = (($resultado.content | Where-Object { $_.type -eq 'text' } | ForEach-Object { $_.text }) -join "`n")
    if ($t.Length -gt $max) { $t = $t.Substring(0, $max) + ' ...' }
    return $t
}

# ---------- login (o mesmo que o Claude faz: registro, tela de login, troca do codigo pela chave) ----------
function B64Url([byte[]]$b) { [Convert]::ToBase64String($b).TrimEnd('=').Replace('+', '-').Replace('/', '_') }
function PostSemRedirecionar([string]$url, [string]$corpo) {
    $req = [Net.HttpWebRequest]::Create($url)
    $req.Method = 'POST'; $req.AllowAutoRedirect = $false; $req.ContentType = 'application/x-www-form-urlencoded'
    $b = [Text.Encoding]::UTF8.GetBytes($corpo); $req.ContentLength = $b.Length
    $s = $req.GetRequestStream(); $s.Write($b, 0, $b.Length); $s.Close()
    try { $r = $req.GetResponse() } catch [Net.WebException] { $r = $_.Exception.Response; if (-not $r) { throw } }
    $res = @{ Status = [int]$r.StatusCode; Location = $r.Headers['Location'] }; $r.Close(); return $res
}
function Entrar([string]$email, [string]$senha) {
    $redirect = 'http://127.0.0.1/sps-testar-mcp'
    $reg = Invoke-RestMethod "$base/register" -Method Post -ContentType 'application/json' -Body (@{
        client_name = 'SPS testar-mcp'; redirect_uris = @($redirect); token_endpoint_auth_method = 'none'
        grant_types = @('authorization_code', 'refresh_token'); response_types = @('code') } | ConvertTo-Json -Compress)
    $script:cliente = $reg.client_id
    $rnd = New-Object byte[] 32; [Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($rnd)
    $verifier = B64Url $rnd
    $challenge = B64Url ([Security.Cryptography.SHA256]::Create().ComputeHash([Text.Encoding]::ASCII.GetBytes($verifier)))
    $q = "response_type=code&client_id=$($reg.client_id)&redirect_uri=$([uri]::EscapeDataString($redirect))&code_challenge=$challenge&code_challenge_method=S256&state=teste&scope=sap-b1"
    $tela = Invoke-WebRequest "$base/authorize?$q" -UseBasicParsing
    if ($tela.Content -notmatch 'name="pedido" value="([^"]+)"') { throw 'A tela de login nao abriu.' }
    $form = "pedido=$([uri]::EscapeDataString($Matches[1]))&email=$([uri]::EscapeDataString($email))&senha=$([uri]::EscapeDataString($senha))&acao=entrar"
    $r = PostSemRedirecionar "$base/sps-login" $form
    if ($r.Status -eq 401) { throw 'E-mail ou senha incorretos (usuario do painel).' }
    if ($r.Status -eq 429) { throw 'Muitas tentativas de login. Espere 15 minutos.' }
    if ($r.Status -ne 302 -or $r.Location -notmatch '[?&]code=([^&]+)') { throw "Login nao concluido (HTTP $($r.Status))." }
    $code = [uri]::UnescapeDataString($Matches[1])
    $tok = Invoke-RestMethod "$base/token" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body (
        "grant_type=authorization_code&code=$([uri]::EscapeDataString($code))&code_verifier=$verifier&client_id=$($reg.client_id)&redirect_uri=$([uri]::EscapeDataString($redirect))")
    $script:chave = $tok.access_token
}

Write-Host "SPS MCP B1 - teste do MCP em $base (somente leitura)" -ForegroundColor White
$falhas = 0
try {
    Passo '1. MCP no ar?'
    try {
        $h = Invoke-WebRequest "$base/health" -UseBasicParsing -TimeoutSec 10
        Ok "health: $($h.StatusCode) $(($h.Content | ConvertFrom-Json).status)"
    } catch { throw "O MCP nao respondeu em $base/health. O servico esta iniciado? $(CorpoDoErro $_)" }

    Passo '1b. Login (usuario do painel - o SAP sera acessado com a base e o usuario SAP dele)'
    if (-not $Email) { $Email = Read-Host 'E-mail do usuario do painel' }
    $seg = Read-Host 'Senha do painel' -AsSecureString
    $senhaTexto = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($seg))
    try { Entrar $Email.Trim() $senhaTexto } catch { throw "Login falhou: $($_.Exception.Message) $(if ($_.Exception.Response) { CorpoDoErro $_ })" } finally { $senhaTexto = $null }
    Ok "login de $Email aceito (chave de acesso recebida)"

    Passo '2. Abrindo sessao MCP (como o Claude faz)'
    try {
        $ini = Mcp 'initialize' @{ protocolVersion = '2025-06-18'; capabilities = @{}; clientInfo = @{ name = 'sps-testar-mcp'; version = '1.0' } }
    } catch {
        $det = CorpoDoErro $_
        if ($det -match 'Invalid Host' -or $det -match '^HTTP 403') { throw "O MCP recusou o endereco ($det). Ajuste MCP_ALLOWED_HOSTS no .env (ex.: 127.0.0.1,localhost,127.0.0.1:$Porta,localhost:$Porta) e reinicie." }
        throw "Falha ao abrir a sessao: $det"
    }
    Ok "servidor: $($ini.serverInfo.name) $($ini.serverInfo.version) | protocolo $($ini.protocolVersion) | sessao $($script:sessao)"
    $null = Mcp 'notifications/initialized' $null -Notificacao

    Passo '3. Ferramentas disponiveis'
    $tools = Mcp 'tools/list' @{}
    Ok (($tools.tools | ForEach-Object { $_.name }) -join ', ')

    Passo "4. Procurando '$Entidade' no SAP (pode levar alguns segundos na 1a vez)"
    $r = Mcp 'tools/call' @{ name = 'b1_find_entities'; arguments = @{ category = 'all'; query = $Entidade; limit = 5 } }
    if ($r.isError) { $falhas++; Erro (TextoDaFerramenta $r) } else { Ok (TextoDaFerramenta $r 300) }

    Passo "5. Campos de '$Entidade'"
    $r = Mcp 'tools/call' @{ name = 'b1_get_entity_schema'; arguments = @{ entityName = $Entidade } }
    if ($r.isError) { $falhas++; Erro (TextoDaFerramenta $r) } else { Ok ("schema recebido (" + (TextoDaFerramenta $r 100000).Length + " caracteres)") }

    Passo "6. Lendo 3 registros de '$Entidade' (somente leitura)"
    $r = Mcp 'tools/call' @{ name = 'b1_read'; arguments = @{ entityName = $Entidade; operation = 'read'; selectString = $Campos; topNumber = 3 } }
    $txt = TextoDaFerramenta $r 800
    if ($r.isError -and $txt -match 'Sensitive read blocked') {
        Write-Host "  PROTEGIDO  Os campos '$Campos' tem dado pessoal (marcado no SAP). O MCP exige que uma pessoa" -ForegroundColor Yellow
        Write-Host "             confirme no chat antes de ler - o Claude mostra essa pergunta; este teste nao responde." -ForegroundColor Yellow
        Write-Host "             E a protecao funcionando. Para o teste, use campos sem dado pessoal, ex.:" -ForegroundColor Yellow
        Write-Host "             -Entidade Items -Campos ItemCode,ItemName" -ForegroundColor Yellow
    }
    elseif ($r.isError) { $falhas++; Erro $txt } else { Ok $txt }
} catch {
    $falhas++
    Erro $_.Exception.Message
} finally {
    if ($script:sessao) {
        try { Invoke-WebRequest -Uri "$base/mcp" -Method Delete -Headers @{ 'Mcp-Session-Id' = $script:sessao; 'Authorization' = "Bearer $($script:chave)" } -UseBasicParsing -TimeoutSec 10 | Out-Null } catch { }
    }
    # desconecta o login de teste (some da lista "Conectados pelo chat")
    if ($script:chave -and $script:cliente) {
        try { Invoke-RestMethod "$base/revoke" -Method Post -ContentType 'application/x-www-form-urlencoded' -Body "token=$($script:chave)&client_id=$($script:cliente)" | Out-Null } catch { }
    }}

Write-Host ''
if ($falhas -eq 0) { Write-Host 'RESULTADO: MCP funcionando de ponta a ponta com o SAP.' -ForegroundColor Green }
else { Write-Host "RESULTADO: $falhas falha(s). Veja acima e o log em C:\ProgramData\SPS-MCP-B1\logs\app.log" -ForegroundColor Red; exit 1 }
