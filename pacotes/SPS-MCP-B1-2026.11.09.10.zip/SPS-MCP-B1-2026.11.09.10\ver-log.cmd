@echo off
rem SPS MCP B1 - abre o log do servico no Bloco de Notas.
rem A pasta de logs so abre para administradores (seguranca): pede a permissao.
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
set "SPSLOG=%ProgramData%\SPS-MCP-B1\logs\servico.log"
if not exist "%SPSLOG%" (
    echo O log ainda nao existe: %SPSLOG%
    pause
    exit /b
)
start "" notepad "%SPSLOG%"
