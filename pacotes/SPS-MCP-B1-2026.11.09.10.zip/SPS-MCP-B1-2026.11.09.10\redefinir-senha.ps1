﻿<#
  SPS MCP B1 - "Esqueci a senha" do painel.

  Roda NO PROPRIO SERVIDOR, como administrador do Windows (use o redefinir-senha.cmd ou o
  atalho "SPS MCP B1 - Redefinir senha" no Menu Iniciar > SPS Group). Quem é administrador
  do servidor já pode tudo nele, por isso é esta a "prova" de que a pessoa pode trocar a senha.
  Não existe pela rede, pelo painel nem por e-mail.

  Mexe só no arquivo de usuários do produto (C:\ProgramData\SPS-MCP-B1\config.json): troca o hash
  da senha do usuário escolhido. Não precisa reiniciar o MCP; quem estava com o painel aberto
  com esse usuário é desconectado.
#>
param([string]$Pasta = $PSScriptRoot)

$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'ui-sps.ps1')
$Dados = if ($env:SPS_DATA_DIR) { $env:SPS_DATA_DIR } else { Join-Path $env:ProgramData 'SPS-MCP-B1' }

function RodarNode([string]$argumentos, [string]$entrada = '') {
    $psi = New-Object Diagnostics.ProcessStartInfo
    $psi.FileName = Join-Path $Pasta 'runtime\SpsMcpB1.exe'
    $psi.Arguments = "`"$(Join-Path $Pasta 'app\dist\sps\redefinir-senha.js')`" $argumentos"
    $psi.UseShellExecute = $false; $psi.CreateNoWindow = $true
    $psi.RedirectStandardInput = $true; $psi.RedirectStandardOutput = $true; $psi.RedirectStandardError = $true
    $psi.EnvironmentVariables['SPS_DATA_DIR'] = $Dados
    $psi.StandardOutputEncoding = [Text.Encoding]::UTF8
    $p = [Diagnostics.Process]::Start($psi)
    if ($entrada) {
        # UTF-8 sem BOM (acentos na senha chegam certos)
        $b = (New-Object Text.UTF8Encoding($false)).GetBytes($entrada)
        $p.StandardInput.BaseStream.Write($b, 0, $b.Length)
    }
    $p.StandardInput.Close()
    $saida = $p.StandardOutput.ReadToEnd(); $null = $p.StandardError.ReadToEnd(); $p.WaitForExit()
    return @{ Codigo = $p.ExitCode; Saida = $saida.Trim() }
}

Abrir-Janela 'SPS MCP B1 - Redefinir senha' 'Redefinir senha do painel' $PSScriptRoot
try {
    Etapa 10 'Conferindo permissões...'
    $principal = New-Object Security.Principal.WindowsPrincipal([Security.Principal.WindowsIdentity]::GetCurrent())
    if (-not $principal.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)) { throw 'Execute como administrador (use o redefinir-senha.cmd).' }
    if (-not (Test-Path (Join-Path $Pasta 'runtime\SpsMcpB1.exe'))) { throw "SPS MCP B1 não encontrado em $Pasta." }
    Feito 'administrador do Windows conferido'

    Etapa 30 'Lendo os usuários do painel...'
    $l = RodarNode '--listar'
    if ($l.Codigo -ne 0) { throw $l.Saida }
    $usuarios = @($l.Saida | ConvertFrom-Json)
    if (-not $usuarios.Count) { throw 'Nenhum usuário cadastrado. Rode o instalar.cmd para criar o superusuário principal.' }
    Feito "$($usuarios.Count) usuário(s) encontrado(s)"

    Etapa 50 'Escolha o usuário e digite a nova senha...'
    $escolha = Pedir-NovaSenha $usuarios
    if (-not $escolha) { Aviso 'cancelado: nenhuma senha foi alterada'; Concluir $false '' | Out-Null; return }

    Etapa 80 'Gravando a nova senha...'
    $json = @{ login = $escolha.Login; senha = $escolha.Senha } | ConvertTo-Json -Compress
    $r = RodarNode '--redefinir' $json
    $escolha = $null; $json = $null
    if ($r.Codigo -ne 0 -or $r.Saida -ne 'OK') { throw ($r.Saida -replace '^ERRO:\s*', '') }
    Feito 'senha redefinida (sessões abertas desse usuário no painel foram encerradas)'
    Concluir $true 'Pronto! Entre no painel com a nova senha.' | Out-Null
} catch {
    Falhou $_.Exception.Message
    Concluir $false "Senha não alterada: $($_.Exception.Message)" | Out-Null
}
