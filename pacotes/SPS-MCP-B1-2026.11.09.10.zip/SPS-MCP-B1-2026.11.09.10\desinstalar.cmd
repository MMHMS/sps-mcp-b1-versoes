@echo off
rem SPS MCP B1 - desinstalar. Pede permissao de administrador e abre a janela de desinstalacao.
net session >nul 2>&1
if %errorlevel% neq 0 (
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)
rem roda a partir de uma copia na pasta temporaria: assim ele pode apagar a pasta do programa
set "SPSTMP=%TEMP%\sps-mcp-b1-desinstalar"
if exist "%SPSTMP%" rmdir /s /q "%SPSTMP%"
mkdir "%SPSTMP%"
for %%F in (desinstalar.ps1 ui-sps.ps1 logo_sps.png sps.ico) do copy /y "%~dp0%%F" "%SPSTMP%\" >nul
start "" powershell -NoProfile -ExecutionPolicy Bypass -WindowStyle Hidden -File "%SPSTMP%\desinstalar.ps1" -Pasta "%~dp0." %*
