﻿# SPS MCP B1 - janela de progresso do instalador e do desinstalador.
# Mesmo visual do instalador do Monitoramento da Service Layer: logo SPS, faixa degradê,
# etapa atual, barra de progresso, detalhe e a lista do que já foi feito.
#
# Uso (dentro de instalar.ps1 / desinstalar.ps1):
#   . (Join-Path $PSScriptRoot 'ui-sps.ps1')
#   Abrir-Janela 'Título da janela' 'Título do topo' $pastaComLogo
#   Etapa 10 'Fazendo algo...'; Detalhe '3 de 10'; Feito 'algo feito'; Aviso 'atenção'
#   Perguntar-SimNao 'título' 'pergunta'      -> $true / $false
#   Perguntar-Texto 'título' 'pergunta' 'padrão' -> texto ('' = cancelou)
#   Concluir $true 'mensagem' 'Abrir o painel'  -> $true se clicou no botão principal
# Com $script:SemJanela = $true tudo vai para o console (automação/testes).

Add-Type -AssemblyName System.Windows.Forms, System.Drawing, Microsoft.VisualBasic
[Windows.Forms.Application]::EnableVisualStyles()

$script:UI = $null
$corMarinho   = [Drawing.Color]::FromArgb(12, 0, 104)
$corAzul      = [Drawing.Color]::FromArgb(0, 133, 229)
$corVerdeAgua = [Drawing.Color]::FromArgb(0, 199, 176)

function Atualizar-Tela { if ($script:UI) { [Windows.Forms.Application]::DoEvents() } }

function Abrir-Janela([string]$tituloJanela, [string]$tituloTopo, [string]$pastaMarca) {
    if ($script:SemJanela) { Write-Host ''; Write-Host "=== $tituloTopo ===" -ForegroundColor White; return }

    # ícone próprio na barra de tarefas (senão aparece o do PowerShell)
    try {
        Add-Type -Namespace SpsMcp -Name App -MemberDefinition '[DllImport("shell32.dll", CharSet = CharSet.Unicode)] public static extern int SetCurrentProcessExplicitAppUserModelID(string id);' -ErrorAction Stop
        [void][SpsMcp.App]::SetCurrentProcessExplicitAppUserModelID('SPSGroup.McpSapB1.Instalador')
    } catch { }

    $form = New-Object Windows.Forms.Form
    $form.Text = $tituloJanela
    $form.ClientSize = New-Object Drawing.Size(580, 400)
    $form.StartPosition = 'CenterScreen'; $form.FormBorderStyle = 'FixedDialog'; $form.MaximizeBox = $false; $form.MinimizeBox = $true
    $form.Font = New-Object Drawing.Font('Segoe UI', 9); $form.BackColor = [Drawing.Color]::White
    $arqIco = Join-Path $pastaMarca 'sps.ico'
    if (Test-Path -LiteralPath $arqIco) { try { $form.Icon = New-Object Drawing.Icon($arqIco) } catch { } }

    # topo branco com a logo, o título e a faixa degradê da SPS
    $topo = New-Object Windows.Forms.Panel; $topo.Location = New-Object Drawing.Point(0, 0); $topo.Size = New-Object Drawing.Size(580, 68); $topo.BackColor = [Drawing.Color]::White
    $topo.Add_Paint({ param($s, $e)
        $g = New-Object Drawing.Drawing2D.LinearGradientBrush((New-Object Drawing.Point(0, 0)), (New-Object Drawing.Point(580, 0)), $corVerdeAgua, $corAzul)
        $e.Graphics.FillRectangle($g, 0, 64, 580, 4); $g.Dispose() })
    $form.Controls.Add($topo)
    $arqLogo = Join-Path $pastaMarca 'logo_sps.png'
    if (Test-Path -LiteralPath $arqLogo) {
        $img = New-Object Windows.Forms.PictureBox
        # carrega numa cópia em memória para não travar o arquivo (o desinstalador apaga a pasta)
        $bytes = [IO.File]::ReadAllBytes($arqLogo)
        $img.Image = [Drawing.Image]::FromStream((New-Object IO.MemoryStream(, $bytes)))
        $img.SizeMode = 'Zoom'; $img.Location = New-Object Drawing.Point(12, 8); $img.Size = New-Object Drawing.Size(110, 50)
        $topo.Controls.Add($img)
    }
    $lblTitulo = New-Object Windows.Forms.Label; $lblTitulo.Text = $tituloTopo; $lblTitulo.Font = New-Object Drawing.Font('Segoe UI', 13)
    $lblTitulo.ForeColor = $corMarinho; $lblTitulo.Location = New-Object Drawing.Point(134, 18); $lblTitulo.Size = New-Object Drawing.Size(436, 30)
    $topo.Controls.Add($lblTitulo)

    $lblEtapa = New-Object Windows.Forms.Label; $lblEtapa.Location = New-Object Drawing.Point(20, 84); $lblEtapa.Size = New-Object Drawing.Size(540, 22)
    $lblEtapa.Font = New-Object Drawing.Font('Segoe UI', 10); $lblEtapa.ForeColor = $corMarinho
    $form.Controls.Add($lblEtapa)
    $barra = New-Object Windows.Forms.ProgressBar; $barra.Location = New-Object Drawing.Point(20, 110); $barra.Size = New-Object Drawing.Size(540, 18); $barra.Style = 'Continuous'
    $form.Controls.Add($barra)
    $lblDetalhe = New-Object Windows.Forms.Label; $lblDetalhe.Location = New-Object Drawing.Point(20, 132); $lblDetalhe.Size = New-Object Drawing.Size(540, 18); $lblDetalhe.ForeColor = [Drawing.Color]::Gray
    $form.Controls.Add($lblDetalhe)
    $lista = New-Object Windows.Forms.TextBox; $lista.Location = New-Object Drawing.Point(20, 156); $lista.Size = New-Object Drawing.Size(540, 184)
    $lista.Multiline = $true; $lista.ReadOnly = $true; $lista.TabStop = $false; $lista.ScrollBars = 'Vertical'
    $lista.BackColor = [Drawing.Color]::FromArgb(244, 246, 251); $lista.BorderStyle = 'FixedSingle'; $lista.Font = New-Object Drawing.Font('Segoe UI', 9)
    $form.Controls.Add($lista)

    $novoBotao = {
        param($texto, $x, $principal)
        $b = New-Object Windows.Forms.Button; $b.Text = $texto; $b.Location = New-Object Drawing.Point($x, 354); $b.Size = New-Object Drawing.Size(170, 32)
        $b.FlatStyle = 'Flat'; $b.FlatAppearance.BorderColor = $corMarinho
        if ($principal) { $b.BackColor = $corMarinho; $b.ForeColor = [Drawing.Color]::White } else { $b.BackColor = [Drawing.Color]::White; $b.ForeColor = $corMarinho }
        $form.Controls.Add($b); return $b
    }
    $btnPrincipal = & $novoBotao 'Abrir' 214 $true; $btnPrincipal.Visible = $false
    $btnFechar = & $novoBotao 'Fechar' 390 $false; $btnFechar.Enabled = $false

    $script:UI = @{ Form = $form; Barra = $barra; Etapa = $lblEtapa; Detalhe = $lblDetalhe; Lista = $lista
        Principal = $btnPrincipal; Fechar = $btnFechar; Trabalhando = $true; Escolha = $false }
    $btnPrincipal.Add_Click({ $script:UI.Escolha = $true; $script:UI.Form.Close() })
    $btnFechar.Add_Click({ $script:UI.Form.Close() })
    # não deixa fechar no X no meio do trabalho (deixaria a instalação pela metade)
    $form.Add_FormClosing({ param($s, $e) if ($script:UI.Trabalhando) { $e.Cancel = $true } })
    $form.Show()
    $form.Activate()
    Atualizar-Tela
}

function Etapa([int]$pct, [string]$texto) {
    if (-not $script:UI) { Write-Host ''; Write-Host ">> $texto" -ForegroundColor Cyan; return }
    $script:UI.Barra.Value = [Math]::Min(100, [Math]::Max(0, $pct))
    $script:UI.Etapa.Text = $texto; $script:UI.Detalhe.Text = ''
    Atualizar-Tela
}

function Progresso([int]$pct) { if ($script:UI) { $script:UI.Barra.Value = [Math]::Min(100, [Math]::Max(0, $pct)); Atualizar-Tela } }

function Detalhe([string]$texto) {
    if (-not $script:UI) { return }
    $script:UI.Detalhe.Text = $texto; Atualizar-Tela
}

function Feito([string]$texto) {
    if (-not $script:UI) { Write-Host "   ok  $texto"; return }
    $script:UI.Lista.AppendText([char]0x2713 + ' ' + $texto + "`r`n"); Atualizar-Tela
}

function Aviso([string]$texto) {
    if (-not $script:UI) { Write-Host "   !   $texto" -ForegroundColor Yellow; return }
    $script:UI.Lista.AppendText('! ' + $texto + "`r`n"); Atualizar-Tela
}

function Falhou([string]$texto) {
    if (-not $script:UI) { Write-Host ''; Write-Host "ERRO: $texto" -ForegroundColor Red; return }
    $script:UI.Etapa.ForeColor = [Drawing.Color]::Firebrick
    $script:UI.Etapa.Text = 'Não foi possível concluir'
    $script:UI.Lista.AppendText("`r`n" + [char]0x2717 + ' ' + ($texto -replace "`n", "`r`n   ") + "`r`n")
    Atualizar-Tela
}

function Perguntar-SimNao([string]$titulo, [string]$texto) {
    if (-not $script:UI) { return ((Read-Host "$texto (S/N)") -match '^\s*[sS]') }
    $r = [Windows.Forms.MessageBox]::Show($script:UI.Form, $texto, $titulo, 'YesNo', 'Warning', 'Button2')
    return ($r -eq 'Yes')
}

function Perguntar-Texto([string]$titulo, [string]$texto, [string]$padrao) {
    if (-not $script:UI) { $r = Read-Host "$texto [Enter = $padrao, C = cancelar]"; if ($r -match '^\s*[cC]') { return '' }; if (-not $r.Trim()) { return $padrao }; return $r.Trim() }
    $script:UI.Form.TopMost = $false
    return ([Microsoft.VisualBasic.Interaction]::InputBox($texto, $titulo, $padrao)).Trim()
}

# Antes de começar: mostra um texto, uma caixa de marcar opcional e os botões
# [textoBotao] / Cancelar. Espera o usuário. Devolve @{ Iniciar = $true/$false; Marcado = $true/$false }.
function Pedir-Inicio([string]$texto, [string]$textoBotao, [string]$textoCaixa = '') {
    if (-not $script:UI) { return @{ Iniciar = $true; Marcado = $false } }
    $ui = $script:UI
    $ui.Etapa.Text = 'Pronto para começar'
    $ui.Lista.Text = $texto
    $caixa = $null
    if ($textoCaixa) {
        $ui.Lista.Height = 150
        $caixa = New-Object Windows.Forms.CheckBox
        $caixa.Text = $textoCaixa; $caixa.Location = New-Object Drawing.Point(20, 314); $caixa.Size = New-Object Drawing.Size(540, 34)
        $caixa.ForeColor = [Drawing.Color]::Firebrick
        $ui.Form.Controls.Add($caixa)
    }
    $ui.Principal.Text = $textoBotao; $ui.Principal.Visible = $true
    $ui.Fechar.Text = 'Cancelar'; $ui.Fechar.Enabled = $true
    # Trabalhando continua $true: a janela NAO fecha durante a espera (o FormClosing cancela);
    # os botões só registram a escolha.
    $ui.Trabalhando = $true; $ui.Escolha = $false
    $script:inicioDecidido = $false
    $hPrincipal = [EventHandler]{ $script:UI.Escolha = $true; $script:inicioDecidido = $true }
    $hFechar = [EventHandler]{ $script:UI.Escolha = $false; $script:inicioDecidido = $true }
    $ui.Principal.Add_Click($hPrincipal); $ui.Fechar.Add_Click($hFechar)
    $ui.Form.Activate()
    while (-not $script:inicioDecidido) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 50 }
    $ui.Principal.Remove_Click($hPrincipal); $ui.Fechar.Remove_Click($hFechar)
    $marcado = [bool]($caixa -and $caixa.Checked)
    if ($caixa) { $caixa.Enabled = $false }
    $iniciar = [bool]$ui.Escolha
    # volta ao modo "trabalhando"
    $ui.Escolha = $false; $ui.Trabalhando = $true
    $ui.Principal.Visible = $false; $ui.Fechar.Text = 'Fechar'; $ui.Fechar.Enabled = $false
    $ui.Lista.Clear()
    return @{ Iniciar = $iniciar; Marcado = $marcado }
}

# Explica um IP em português: IP fixo, faixa (de .. a .., N endereços) ou erro.
function Descrever-Ip([string]$t) {
    $t = $t.Trim()
    if (-not $t) { return '' }
    $num = { param($ip) $p = $ip.Split('.'); if ($p.Count -ne 4) { return $null }; $n = [double]0
        foreach ($s in $p) { if ($s -notmatch '^\d{1,3}$' -or [int]$s -gt 255) { return $null }; $n = $n * 256 + [int]$s }; return $n }
    $txt = { param($n) (@(24, 16, 8, 0) | ForEach-Object { [math]::Floor($n / [math]::Pow(2, $_)) % 256 }) -join '.' }
    if ($t -match '^([\d.]+)/(\d{1,3})$') {
        $base = & $num $Matches[1]; $bits = [int]$Matches[2]
        if ($null -eq $base) { return "$t : IP antes da / incompleto" }
        if ($bits -gt 32) { return "$t : depois da / o máximo é 32 (o comum é /24)" }
        if ($bits -eq 32) { return "$t : IP fixo (uma máquina)" }
        $tam = [math]::Pow(2, 32 - $bits); $ini = $base - ($base % $tam)
        return ("$t : faixa de {0} a {1} ({2:N0} endereços)" -f (& $txt ($ini + 1)), (& $txt ($ini + $tam - 2)), ($tam - 2))
    }
    if ($t -eq '127.0.0.1') { return "$t : só este servidor" }
    if ($null -ne (& $num $t)) { return "$t : IP fixo (uma máquina)" }
    return "$t : não é um IP (ex.: 10.212.135.31 ou 10.212.135.0/24)"
}

# Conferência da senha enquanto digita: tamanho, força e se as duas são iguais.
function Texto-ConferenciaSenha([string]$s1, [string]$s2) {
    $sim = [char]0x2713; $nao = [char]0x2717   # marcas de certo/errado (por código: o arquivo-fonte pode estar sem BOM)
    if (-not $s1) { return @('', [Drawing.Color]::Gray) }
    if ($s1.Length -lt 8) { return @("$nao Faltam $(8 - $s1.Length) caractere(s) (mínimo 8)", [Drawing.Color]::Firebrick) }
    $pontos = 0
    if ($s1.Length -ge 12) { $pontos++ }
    if ($s1 -cmatch '[a-z]' -and $s1 -cmatch '[A-Z]') { $pontos++ }
    if ($s1 -match '\d') { $pontos++ }
    if ($s1 -match '[^a-zA-Z0-9]') { $pontos++ }
    $forca = @('fraca', 'fraca', 'média', 'forte', 'forte')[$pontos]
    if (-not $s2) { return @("Senha $forca · agora repita a senha", [Drawing.Color]::FromArgb(0, 96, 159)) }
    if ($s1 -ne $s2) { return @("$nao As senhas não conferem (senha $forca)", [Drawing.Color]::Firebrick) }
    return @("$sim As senhas conferem (senha $forca)", [Drawing.Color]::FromArgb(15, 125, 95))
}
function Ligar-ConferenciaSenha($tb1, $tb2, $rotulo) {
    # as referências ficam no Tag dos campos (o evento roda depois que esta função já terminou)
    $par = @{ A = $tb1; B = $tb2; R = $rotulo }
    $tb1.Tag = $par; $tb2.Tag = $par
    $atualizar = { param($s, $e) $p = $s.Tag; $r = Texto-ConferenciaSenha $p.A.Text $p.B.Text; $p.R.Text = $r[0]; $p.R.ForeColor = $r[1] }
    $tb1.Add_TextChanged($atualizar); $tb2.Add_TextChanged($atualizar)
}

# Janela do "Esqueci a senha": escolhe o usuário e digita a nova senha 2 vezes.
# $usuarios = lista do redefinir-senha.js --listar. Devolve @{ Login; Senha } ou $null se cancelar.
function Pedir-NovaSenha($usuarios) {
    $f = New-Object Windows.Forms.Form
    $f.Text = 'Redefinir senha do painel'; $f.ClientSize = New-Object Drawing.Size(440, 330)
    $f.StartPosition = 'CenterParent'; $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.MinimizeBox = $false
    $f.Font = New-Object Drawing.Font('Segoe UI', 9); $f.BackColor = [Drawing.Color]::White
    if ($script:UI.Form.Icon) { $f.Icon = $script:UI.Form.Icon }
    $t = New-Object Windows.Forms.Label; $t.Text = 'Nova senha para entrar no painel'
    $t.Font = New-Object Drawing.Font('Segoe UI', 11); $t.ForeColor = $corMarinho; $t.Location = New-Object Drawing.Point(20, 14); $t.Size = New-Object Drawing.Size(400, 24)
    $f.Controls.Add($t)
    $a = New-Object Windows.Forms.Label; $a.ForeColor = [Drawing.Color]::Gray; $a.Location = New-Object Drawing.Point(20, 40); $a.Size = New-Object Drawing.Size(400, 34)
    $a.Text = 'Quem estiver com o painel aberto com este usuário é desconectado e entra de novo com a nova senha.'
    $f.Controls.Add($a)
    $l = New-Object Windows.Forms.Label; $l.Text = 'Usuário'; $l.Location = New-Object Drawing.Point(20, 80); $l.Size = New-Object Drawing.Size(400, 18)
    $cb = New-Object Windows.Forms.ComboBox; $cb.DropDownStyle = 'DropDownList'; $cb.Location = New-Object Drawing.Point(20, 98); $cb.Size = New-Object Drawing.Size(400, 24)
    foreach ($u in $usuarios) {
        $marca = if ($u.principal) { ' - superusuário principal' } elseif ($u.superusuario) { ' - superusuário' } elseif ($u.admin) { ' - administrador' } else { '' }
        $inativo = if (-not $u.ativo) { ' (inativo)' } else { '' }
        [void]$cb.Items.Add("$($u.nome) <$($u.login)>$marca$inativo")
    }
    $iPrincipal = [array]::FindIndex([object[]]@($usuarios), [Predicate[object]]{ param($x) $x.principal })
    $cb.SelectedIndex = [Math]::Max(0, $iPrincipal)
    $f.Controls.Add($l); $f.Controls.Add($cb)
    $campos = @{}; $y = 130
    foreach ($c in @(@('senha', 'Nova senha (mínimo 8 caracteres)'), @('senha2', 'Repita a nova senha'))) {
        $l = New-Object Windows.Forms.Label; $l.Text = $c[1]; $l.Location = New-Object Drawing.Point(20, $y); $l.Size = New-Object Drawing.Size(400, 18)
        $tb = New-Object Windows.Forms.TextBox; $tb.Location = New-Object Drawing.Point(20, ($y + 18)); $tb.Size = New-Object Drawing.Size(400, 24); $tb.UseSystemPasswordChar = $true
        $f.Controls.Add($l); $f.Controls.Add($tb); $campos[$c[0]] = $tb; $y += 48
    }
    $conf = New-Object Windows.Forms.Label; $conf.Location = New-Object Drawing.Point(20, $y); $conf.Size = New-Object Drawing.Size(400, 18)
    $f.Controls.Add($conf)
    Ligar-ConferenciaSenha $campos.senha $campos.senha2 $conf
    $erro = New-Object Windows.Forms.Label; $erro.ForeColor = [Drawing.Color]::Firebrick; $erro.Location = New-Object Drawing.Point(20, ($y + 24)); $erro.Size = New-Object Drawing.Size(240, 40)
    $f.Controls.Add($erro)
    $ok = New-Object Windows.Forms.Button; $ok.Text = 'Redefinir'; $ok.Location = New-Object Drawing.Point(256, 286); $ok.Size = New-Object Drawing.Size(86, 30)
    $ok.FlatStyle = 'Flat'; $ok.BackColor = $corMarinho; $ok.ForeColor = [Drawing.Color]::White
    $cancelar = New-Object Windows.Forms.Button; $cancelar.Text = 'Cancelar'; $cancelar.Location = New-Object Drawing.Point(346, 286); $cancelar.Size = New-Object Drawing.Size(76, 30)
    $cancelar.FlatStyle = 'Flat'; $cancelar.DialogResult = 'Cancel'
    $f.Controls.Add($ok); $f.Controls.Add($cancelar); $f.AcceptButton = $ok; $f.CancelButton = $cancelar
    $ok.Add_Click({
        if ($campos.senha.Text.Length -lt 8) { $erro.Text = 'A senha precisa ter pelo menos 8 caracteres.'; return }
        if ($campos.senha.Text -ne $campos.senha2.Text) { $erro.Text = 'As senhas não conferem.'; return }
        $f.DialogResult = 'OK'; $f.Close()
    })
    $r = $f.ShowDialog($script:UI.Form)
    if ($r -ne 'OK') { return $null }
    return @{ Login = @($usuarios)[$cb.SelectedIndex].login; Senha = $campos.senha.Text }
}

# Janela para criar o superusuário principal: e-mail, nome, senha e repetir senha.
# Devolve @{ Email; Nome; Senha } ou $null se cancelar.
function Pedir-Superusuario([string]$pastaMarca) {
    if (-not $script:UI) {
        Write-Host ''; Write-Host 'Superusuario principal (dono do painel):' -ForegroundColor White
        $email = Read-Host 'E-mail'; $nome = Read-Host 'Nome'
        $s1 = Read-Host 'Senha (min. 8)' -AsSecureString; $s2 = Read-Host 'Repita a senha' -AsSecureString
        $p1 = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s1))
        $p2 = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($s2))
        if ($p1 -ne $p2) { Write-Host 'As senhas nao conferem.' -ForegroundColor Red; return $null }
        return @{ Email = $email.Trim(); Nome = $nome.Trim(); Senha = $p1; Ips = @() }
    }
    $f = New-Object Windows.Forms.Form
    $f.Text = 'Superusuário principal'; $f.ClientSize = New-Object Drawing.Size(440, 362)
    $f.StartPosition = 'CenterParent'; $f.FormBorderStyle = 'FixedDialog'; $f.MaximizeBox = $false; $f.MinimizeBox = $false
    $f.Font = New-Object Drawing.Font('Segoe UI', 9); $f.BackColor = [Drawing.Color]::White
    if ($script:UI.Form.Icon) { $f.Icon = $script:UI.Form.Icon }
    $t = New-Object Windows.Forms.Label; $t.Text = 'Crie o superusuário principal (dono do painel)'
    $t.Font = New-Object Drawing.Font('Segoe UI', 11); $t.ForeColor = $corMarinho; $t.Location = New-Object Drawing.Point(20, 14); $t.Size = New-Object Drawing.Size(400, 24)
    $f.Controls.Add($t)
    $a = New-Object Windows.Forms.Label; $a.ForeColor = [Drawing.Color]::Gray; $a.Location = New-Object Drawing.Point(20, 40); $a.Size = New-Object Drawing.Size(400, 34)
    $a.Text = 'Ele entra no painel e no chat (login com este e-mail e senha), não pode ser excluído e decide quem mais cadastra usuários.'
    $f.Controls.Add($a)
    $campos = @{}
    $y = 80
    foreach ($c in @(@('email', 'E-mail', $false), @('nome', 'Nome', $false),
            @('senha', 'Senha (mínimo 8 caracteres)', $true), @('senha2', 'Repita a senha', $true))) {
        $l = New-Object Windows.Forms.Label; $l.Text = $c[1]; $l.Location = New-Object Drawing.Point(20, $y); $l.Size = New-Object Drawing.Size(400, 18)
        $tb = New-Object Windows.Forms.TextBox; $tb.Location = New-Object Drawing.Point(20, ($y + 18)); $tb.Size = New-Object Drawing.Size(400, 24)
        if ($c[2]) { $tb.UseSystemPasswordChar = $true }
        $f.Controls.Add($l); $f.Controls.Add($tb); $campos[$c[0]] = $tb
        $y += 48
    }
    # conferência da senha na hora (tamanho, força, se as duas conferem)
    $conf = New-Object Windows.Forms.Label; $conf.Location = New-Object Drawing.Point(20, 274); $conf.Size = New-Object Drawing.Size(400, 18)
    $f.Controls.Add($conf)
    Ligar-ConferenciaSenha $campos.senha $campos.senha2 $conf
    $erro = New-Object Windows.Forms.Label; $erro.ForeColor = [Drawing.Color]::Firebrick; $erro.Location = New-Object Drawing.Point(20, 298); $erro.Size = New-Object Drawing.Size(240, 44)
    $f.Controls.Add($erro)
    $ok = New-Object Windows.Forms.Button; $ok.Text = 'Criar'; $ok.Location = New-Object Drawing.Point(266, 314); $ok.Size = New-Object Drawing.Size(76, 30)
    $ok.FlatStyle = 'Flat'; $ok.BackColor = $corMarinho; $ok.ForeColor = [Drawing.Color]::White
    $cancelar = New-Object Windows.Forms.Button; $cancelar.Text = 'Cancelar'; $cancelar.Location = New-Object Drawing.Point(346, 314); $cancelar.Size = New-Object Drawing.Size(76, 30)
    $cancelar.FlatStyle = 'Flat'; $cancelar.DialogResult = 'Cancel'
    $f.Controls.Add($ok); $f.Controls.Add($cancelar); $f.AcceptButton = $ok; $f.CancelButton = $cancelar
    $ok.Add_Click({
        $e = $campos.email.Text.Trim(); $n = $campos.nome.Text.Trim(); $s = $campos.senha.Text
        if ($e -notmatch '^[^\s@]+@[^\s@]+\.[^\s@]+$') { $erro.Text = 'Informe um e-mail válido.'; return }
        if (-not $n) { $erro.Text = 'Informe o nome.'; return }
        if ($s.Length -lt 8) { $erro.Text = 'A senha precisa ter pelo menos 8 caracteres.'; return }
        if ($s -ne $campos.senha2.Text) { $erro.Text = 'As senhas não conferem.'; return }
        $f.DialogResult = 'OK'; $f.Close()
    })
    $r = $f.ShowDialog($script:UI.Form)
    if ($r -ne 'OK') { return $null }
    return @{ Email = $campos.email.Text.Trim(); Nome = $campos.nome.Text.Trim(); Senha = $campos.senha.Text; Ips = @() }
}

# Fim: mostra o resultado, libera os botões e espera o usuário fechar.
function Concluir([bool]$ok, [string]$mensagem, [string]$textoPrincipal = '') {
    if (-not $script:UI) {
        if ($ok) { Write-Host ''; Write-Host $mensagem -ForegroundColor Green } else { Write-Host $mensagem -ForegroundColor Red }
        return $false
    }
    $script:UI.Trabalhando = $false
    if ($ok) {
        $script:UI.Barra.Value = 100
        $script:UI.Etapa.ForeColor = [Drawing.Color]::FromArgb(15, 125, 95)
        $script:UI.Etapa.Text = $mensagem
    }
    if ($textoPrincipal) { $script:UI.Principal.Text = $textoPrincipal; $script:UI.Principal.Visible = $true }
    $script:UI.Fechar.Enabled = $true
    $script:UI.Form.TopMost = $true; $script:UI.Form.Activate(); $script:UI.Form.TopMost = $false
    while ($script:UI.Form.Visible) { [Windows.Forms.Application]::DoEvents(); Start-Sleep -Milliseconds 50 }
    return $script:UI.Escolha
}
